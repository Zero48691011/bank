default_app_config = "bank_project.apps.BankProjectConfig"

